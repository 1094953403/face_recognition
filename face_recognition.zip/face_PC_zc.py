 #!/usr/bin/python
# -*- coding:utf8 -*- 
import cv2
import requests
import json
import pickle
import numpy as np
import time

payload = {
			'api_key': 'db9imPdwPuABdAUsaXzqLF8jnzKxuw7k',  
		    'api_secret': '8Zpr10gYFbIXeU5QWz-CJtEKlJejvpPd',
		 }

payload_detect={
				'api_key': 'db9imPdwPuABdAUsaXzqLF8jnzKxuw7k',  
		    	'api_secret': '8Zpr10gYFbIXeU5QWz-CJtEKlJejvpPd',
 			    'return_attributes': 'gender,smiling,emotion,ethnicity,age,glass',
 			    'return_landmark' : 2		#1是83个点，2是106个点
		       }
def send_oneface(pic_name):
	#basic_dir = r'C:\Users\13115\Desktop\人脸识别\pic1'
	basic_dir = r'.\pic1'#而如果是以r开头表示为普通字符，是“\n”那么表示一个反斜杠字符，一个字母n，而不是表示换行了。
	url = 'https://api-cn.faceplusplus.com/facepp/v3/detect' 
	files = {'image_file': open(basic_dir+'/'+pic_name, 'rb')}
	r = requests.post(url, files=files, data=payload)  
	face = (r.json().get('faces'))#将json格式解码转换成python的数据格式
	tem_zc=(r.json())
	# print(tem_zc)                        ##request的一个内置的JSON解码器https://blog.csdn.net/iloveyin/article/details/21444613
	# print(face)
	if face is None:
		print('there is no face found in %s' %pic_name)
	else:
		a = face[0]['face_token']
		print('faceId1(face_token):%s' %a)
		print(type(a))
		with open(basic_dir+'\\a.txt' , 'a') as f:#faceID1为对应的token码，存入txt
			f.write(a+'\n')
		#add_faceset(a)#将token码上传
		return a


def detect_oneface_condition(pic_name):

	print('face_condition')
	url = 'https://api-cn.faceplusplus.com/facepp/v3/detect' 
	files = {'image_file': open(pic_name, 'rb')}
	r = requests.post(url, files=files, data=payload_detect)  
	face = (r.json().get('faces'))#将json格式解码转换成python的数据格式
	#tem_zc=(r.json())
	#print(tem_zc)                        ##request的一个内置的JSON解码器https://blog.csdn.net/iloveyin/article/details/21444613
	# print(face)
	if face is None:
		print('there is no face found in %s' %pic_name)
	else:
		pass
		#print(face[0]['attributes']['gender']['value'])

		return face

#在faceset中添加facetoken
def add_faceset(face_token):
	url = 'https://api-cn.faceplusplus.com/facepp/v3/faceset/addface'
	payload['outer_id'] = 'test'
	payload['face_tokens'] = str(face_token)
	r = requests.post(url,data=payload)  
	print(r.json())

# faceId1 = send_oneface('cjc1.jpg')
# faceId2 = send_oneface('mlh1.jpg')

def faceset_remove():
	url = 'https://api-cn.faceplusplus.com/facepp/v3/faceset/removeface'
	payload['faceset_token'] = '32d46fcd929fe5d7c811e26f9c682878'
	#outer_id和faceset_token二选一
	#payload['outer_id'] = 'test'
	payload['face_tokens']='RemoveAllFaceTokens'
	r = requests.post(url,data=payload)  
	print(r.json())

#search 查找功能
def find_face(pic_name):
	url = 'https://api-cn.faceplusplus.com/facepp/v3/search'  
	payload['outer_id'] = 'test'
	files = {'image_file': open(pic_name, 'rb')}  
	r = requests.post(url,files=files,data=payload)  #post()的输入可以是python的字典
	print(r.json())
	return r.json()

def onenet_put_pic(device,image_name):
	url='http://api.heclouds.com/bindata'
	headers={"api-key":'mqAq4mOMT=lZQMMsHmJx7Gj3hac=', #改成你的APIKEY
			 "Content-Type":"image/jpg",
			} 
	querystring = {"device_id": str(device), "datastream_id": "picture"}#每个设备都有所有的数据流
	
	with open(image_name, 'rb') as f:
		r=requests.post(url, params=querystring, headers=headers, data=f)
		# print(r.json())
		return r

def onenet_put_data(device,id,data):
	url='http://api.heclouds.com/devices/'+str(device)+'/datapoints'
	apiheaders={"api-key":'mqAq4mOMT=lZQMMsHmJx7Gj3hac='}
	values={ 'datastreams':[{"id":id,"datapoints":[{"value":data}]}] }
	jdata = json.dumps(values)   # 对数据进行JSON格式化编码
	#print(jdata) #打印json内容
	r=requests.post(url,headers=apiheaders,data=jdata)
	# print(r.json())
	return r

#******************************识别部分
# http://api.heclouds.com/devices/22837269/datapoints
cap=cv2.VideoCapture(0)
device = 22837269
while True:
	#读取帧摄像头
	s, img = cap.read()
	if s==True:
		cv2.imshow('test',img)
		key = cv2.waitKey(1) & 0xFF
		#退出
		if key == 27:
			break
		if key == ord(' '):
			time_now = time.strftime('%m-%d %H-%M-%S',time.localtime(time.time()))
			pic_name1 = "./pic_r/"+time_now+".jpg"
			cv2.imwrite(pic_name1,img)
			print('保存图片成功')

			onenet_put_pic(device,pic_name1) #提交给onenet
			data = find_face(pic_name1) #对比人脸库
            
			if "error_message" in data:
				print("高并发报错")
			elif len(data["faces"]) == 0:
				print('\n未检测到人脸')
				onenet_put_data(device,"people","没有人脸")
			else:
				if data["results"][0]["face_token"] == "37752bc1efbc7af3a9b765eec9928ab9" and data["results"][0]["confidence"]>=data["thresholds"]["1e-4"]:
					print('\n这是蔡金川')
					onenet_put_data(device,"people","CJC")

				elif data["results"][0]["face_token"] == "d2451289c6b90c59a24d22f0edfe6818" and data["results"][0]["confidence"]>=data["thresholds"]["1e-4"]:
					print('\n这是杨幂')
					onenet_put_data(device,"people","杨幂")

				elif data["results"][0]["face_token"] == "9181c71c390e5b9e3509176c5bea8971" and data["results"][0]["confidence"]>=data["thresholds"]["1e-4"]:
					print('\n这是张超')
					onenet_put_data(device,"people","张超")

				elif data["results"][0]["face_token"] == "82da6947e727b1d463e6823d8bbe1263" and data["results"][0]["confidence"]>=data["thresholds"]["1e-4"]:
					print('\n这货是封通通')
					onenet_put_data(device,"people","封通通")
				else:
					print('\n陌生人')
					onenet_put_data(device,"people","陌生人")
                #人脸状况识别部分
				print('\n')
				face_attributes = detect_oneface_condition(pic_name1)
				print(face_attributes)

				print('gender: %s'%face_attributes[0]['attributes']['gender']['value'])
				onenet_put_data(device,"gender",face_attributes[0]['attributes']['gender']['value'])#上传至云
				print('age: %d'%face_attributes[0]['attributes']['age']['value'])
				onenet_put_data(device,"age",face_attributes[0]['attributes']['age']['value'])
				print('ethnicity: %s'%face_attributes[0]['attributes']['ethnicity']['value'])
				onenet_put_data(device,"ethnicity",face_attributes[0]['attributes']['ethnicity']['value'])
				emotion=max(face_attributes[0]['attributes']['emotion'], key=face_attributes[0]['attributes']['emotion'].get)
				print('emotion: %s'%emotion)
				onenet_put_data(device,"emotion",emotion)

				
				#在图像上画出landmark		
				print(face_attributes[0]['landmark'])
				np.save('./landmark_temp/my_file.npy', face_attributes[0]['landmark']) 		
				read_lanmark = np.load('./landmark_temp/my_file.npy').item()
				#print(read_lanmark)
				img = cv2.imread(pic_name1)
				#显示所有的landmark
				for key1,value1 in read_lanmark.items():
					for key2,value2 in value1.items():
						#print(key2+':'+str(value2))
						if key2=='y':
						  	temp_row=value2
						else:
							temp_column=value2
							img[temp_row, temp_column] = [0, 0, 255]
							#每个landmark的8邻域
							img[temp_row-1, temp_column-1] = [0, 0, 255]
							img[temp_row, temp_column-1] = [0, 0, 255]
							img[temp_row+1, temp_column-1] = [0, 0, 255]
							img[temp_row+1, temp_column] = [0, 0, 255]
							img[temp_row+1, temp_column+1] = [0, 0, 255]
							img[temp_row, temp_column+1] = [0, 0, 255]
							img[temp_row-1, temp_column+1] = [0, 0, 255]
							img[temp_row-1, temp_column] = [0, 0, 255]


				cv2.imwrite('./landmark_temp/changePixel.jpg', img)
				img2 = cv2.imread('./landmark_temp/changePixel.jpg')
				cv2.imshow('image', img2)
				cv2.waitKey(0)#等待，防止图片is fleeting
									
#******************************识别部分
				
'''
#******************************图片上传部分	

#拍照上传
#opencv 按空格拍照 并上传faceset
cap=cv2.VideoCapture(0)
i=1
while True:
	#读取帧摄像头
	s, img = cap.read()
	if s==True:
		cv2.imshow('test',img)
		key = cv2.waitKey(1) & 0xFF
		#esc退出
		if key == 27:
			break
		if key == ord(' '):
			i=i+1
			pic_name = "test"+str(i)+".jpg"
			cv2.imwrite(r".\pic1"+'/'+pic_name,img)
			print('保存图片成功')
			face_token = send_oneface(pic_name)  #上传图片
			add_faceset(face_token)	#添加facetoken到faceset
#******************************图片上传部分			

'''


'''
#********************************删除faceset中的token码
#删除faceset里的所有token
faceset_remove()
#********************************删除faceset中的token码
'''
